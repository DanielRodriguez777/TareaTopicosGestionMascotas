﻿using GestionDeMascotas.Comandos;
using GestionDeMascotas.Modelos;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace GestionDeMascotas.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        public ObservableCollection<MascotaViewModel> Mascotas { get; } = new ObservableCollection<MascotaViewModel>();

        private MascotaViewModel _mascotaSeleccionada;
        public MascotaViewModel MascotaSeleccionada
        {
            get => _mascotaSeleccionada;
            set
            {
                _mascotaSeleccionada = value;
                OnPropertyChanged(nameof(MascotaSeleccionada));
            }
        }

        public string NuevoNombre { get; set; }
        public string NuevaEspecie { get; set; }
        public int NuevaEdad { get; set; }
        public string NuevoDueño { get; set; }

        public ICommand AgregarMascotaCommand { get; }
        public ICommand ModificarMascotaCommand { get; }
        public ICommand EliminarMascotaCommand { get; }

        public MainViewModel()
        {
            AgregarMascotaCommand = new RelayCommand(AgregarMascota);
            ModificarMascotaCommand = new RelayCommand(ModificarMascota, _ => MascotaSeleccionada != null);
            EliminarMascotaCommand = new RelayCommand(EliminarMascota, _ => MascotaSeleccionada != null);
        }

        private void AgregarMascotaEjemplo(string nombre, string especie, int edad, string dueño)
        {
            var mascota = new Macotas { Nombre = nombre, Especie = especie, Edad = edad, Dueño = dueño };
            Mascotas.Add(new MascotaViewModel(mascota));
        }

        private void AgregarMascota(object obj)
        {
            if (string.IsNullOrWhiteSpace(NuevoNombre)) return;

            var mascota = new Macotas
            {
                Nombre = NuevoNombre,
                Especie = NuevaEspecie,
                Edad = NuevaEdad,
                Dueño = NuevoDueño
            };

            Mascotas.Add(new MascotaViewModel(mascota));
            NuevoNombre = string.Empty;
            NuevaEspecie = string.Empty;
            NuevaEdad = 0;
            NuevoDueño = string.Empty;
            OnPropertyChanged(nameof(NuevoNombre));
            OnPropertyChanged(nameof(NuevaEspecie));
            OnPropertyChanged(nameof(NuevaEdad));
            OnPropertyChanged(nameof(NuevoDueño));
        }

        private void ModificarMascota(object obj)
        {
            if (MascotaSeleccionada == null) return;

            MascotaSeleccionada.Nombre = NuevoNombre;
            MascotaSeleccionada.Especie = NuevaEspecie;
            MascotaSeleccionada.Edad = NuevaEdad;
            MascotaSeleccionada.Dueño = NuevoDueño;
        }

        private void EliminarMascota(object obj)
        {
            if (MascotaSeleccionada != null)
            {
                Mascotas.Remove(MascotaSeleccionada);
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}