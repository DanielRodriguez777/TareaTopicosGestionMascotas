﻿using GestionDeMascotas.Comandos;
using GestionDeMascotas.Modelos;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace GestionDeMascotas.ViewModels
{
    public class MascotaViewModel : INotifyPropertyChanged
    {
        private Macotas _mascota;
        public Macotas Mascota
        {
            get => _mascota;
            set
            {
                if (_mascota != value)
                {
                    _mascota = value;
                    OnPropertyChanged(nameof(Mascota));
                }
            }
        }
        public string Nombre
        {
            get => Mascota.Nombre;
            set
            {
                if (Mascota.Nombre != value)
                {
                    Mascota.Nombre = value;
                    OnPropertyChanged(nameof(Nombre));
                }
            }
        }
        public string Especie
        {
            get => Mascota.Especie;
            set
            {
                if (Mascota.Especie != value)
                {
                    Mascota.Especie = value;
                    OnPropertyChanged(nameof(Especie));
                }
            }
        }
        public int Edad
        {
            get => Mascota.Edad;
            set
            {
                if (Mascota.Edad != value)
                {
                    Mascota.Edad = value;
                    OnPropertyChanged(nameof(Edad));
                }
            }
        }
        public string Dueño
        {
            get => Mascota.Dueño;
            set
            {
                if (Mascota.Dueño != value)
                {
                    Mascota.Dueño = value;
                    OnPropertyChanged(nameof(Dueño));
                }
            }
        }
        public MascotaViewModel(Macotas mascota)
        {
            Mascota = mascota;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}