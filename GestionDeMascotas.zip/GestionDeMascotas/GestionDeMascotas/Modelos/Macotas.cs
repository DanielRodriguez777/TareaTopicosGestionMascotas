﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionDeMascotas.Modelos
{
    public class Macotas
    {
        public string Nombre { get; set; }
        public string Especie { get; set; } 
        public int Edad { get; set; }
        public string Dueño { get; set; } 
    }
}
